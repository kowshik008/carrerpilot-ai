# CareerPilot AI Utilities
